// redux/movieReducer.js
const initialState = {
  moviesSearch: [],
};
 
export default (state = initialState, action) => {
  switch (action.type) {
    case 'MOVIE_FETCHING':
      console.log("---------------")
      console.log(action.payload)
      return {
        ...state,
      };
    default:
      return state;
  }
};