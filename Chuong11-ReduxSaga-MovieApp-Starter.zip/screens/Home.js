/**
 * Thực hành tích hợp API sử dụng Redux Saga + Axios
 * Màn hình: Home
 * Biên tập: VNTALKING.COM
 */
import React, { useState } from 'react';
import { 
  StyleSheet, 
  View, 
  Text, 
  Image, 
  TextInput, 
  TouchableOpacity, 
  FlatList,
} from 'react-native';

import { useSelector, useDispatch } from 'react-redux';

const Home = () => {
  const dispatch = useDispatch();
  const movies = [
    {
      "Title": "Star Wars: Episode IV - A New Hope",
      "Year": "1977",
      "imdbID": "tt0076759",
      "Type": "movie",
      "Poster": "https://m.media-amazon.com/images/M/MV5BOTA5NjhiOTAtZWM0ZC00MWNhLThiMzEtZDFkOTk2OTU1ZDJkXkEyXkFqcGdeQXVyMTA4NDI1NTQx._V1_SX300.jpg"
    },
    {
      "Title": "Star Wars: Episode V - The Empire Strikes Back",
      "Year": "1980",
      "imdbID": "tt0080684",
      "Type": "movie",
      "Poster": "https://m.media-amazon.com/images/M/MV5BYmU1NDRjNDgtMzhiMi00NjZmLTg5NGItZDNiZjU5NTU4OTE0XkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_SX300.jpg"
    },
    {
      "Title": "Star Wars: Episode VI - Return of the Jedi",
      "Year": "1983",
      "imdbID": "tt0086190",
      "Type": "movie",
      "Poster": "https://m.media-amazon.com/images/M/MV5BOWZlMjFiYzgtMTUzNC00Y2IzLTk1NTMtZmNhMTczNTk0ODk1XkEyXkFqcGdeQXVyNTAyODkwOQ@@._V1_SX300.jpg"
    },
    {
      "Title": "Star Wars: Episode VII - The Force Awakens",
      "Year": "2015",
      "imdbID": "tt2488496",
      "Type": "movie",
      "Poster": "https://m.media-amazon.com/images/M/MV5BOTAzODEzNDAzMl5BMl5BanBnXkFtZTgwMDU1MTgzNzE@._V1_SX300.jpg"
    },
    {
      "Title": "Star Wars: Episode I - The Phantom Menace",
      "Year": "1999",
      "imdbID": "tt0120915",
      "Type": "movie",
      "Poster": "https://m.media-amazon.com/images/M/MV5BYTRhNjcwNWQtMGJmMi00NmQyLWE2YzItODVmMTdjNWI0ZDA2XkEyXkFqcGdeQXVyNTAyODkwOQ@@._V1_SX300.jpg"
    },
    {
      "Title": "Star Wars: Episode III - Revenge of the Sith",
      "Year": "2005",
      "imdbID": "tt0121766",
      "Type": "movie",
      "Poster": "https://m.media-amazon.com/images/M/MV5BNTc4MTc3NTQ5OF5BMl5BanBnXkFtZTcwOTg0NjI4NA@@._V1_SX300.jpg"
    },
    {
      "Title": "Star Wars: Episode II - Attack of the Clones",
      "Year": "2002",
      "imdbID": "tt0121765",
      "Type": "movie",
      "Poster": "https://m.media-amazon.com/images/M/MV5BMDAzM2M0Y2UtZjRmZi00MzVlLTg4MjEtOTE3NzU5ZDVlMTU5XkEyXkFqcGdeQXVyNDUyOTg3Njg@._V1_SX300.jpg"
    }
  ]


  const [keyword, setKeyword] = useState("");

  const search = () => {
    console.log("send action with keyword: " + keyword);
  };

  const renderMovieItem = (item) => {
    return (
    <View style={styles.itemContainer}>
      <Image source={{uri: item.Poster}} style={styles.poster} />
      <View style={{marginHorizontal: 10}}>
        <Text style={styles.movieName}>{item.Title}</Text>
        <Text>Năm phát hành: {item.Year}</Text>
      </View>
    </View>
    )
  }

  return (
    <View style={{ flex: 1 }}>
      <View style={{ alignItems: 'center', backgroundColor: "#cc3333" }}>
        <Text style={styles.textHeader}>Kết nối API sử dụng Redux Saga + Axios</Text>
        <Text style={{ color: "#FFFFFF" }}>VNTALKING.COM</Text>
      </View>
      {/* Giao diện thanh tìm kiếm */}
      <View style={styles.container}>
        <TextInput
          style={styles.searchInput}
          placeholder="Nhập từ khóa tìm kiếm"
          value={keyword}
          onChangeText={setKeyword}
        />
        <TouchableOpacity
          onPress={search}
          style={{ ...styles.btn, backgroundColor: '#3d85c6' }}>
          <Text style={styles.btnText}> Tìm kiếm </Text>
        </TouchableOpacity>
        {/* Giao diện danh sách phim được tìm thấy */}
        <FlatList
          data={movies}
          renderItem={({item}) => renderMovieItem(item)}
          ListHeaderComponent={() => (!movies.length ? 
            <Text>Không tìm thấy kêt quả phù hợp</Text>  
            : null)}
        />
      </View>
      
    </View>
  )
}

const styles = StyleSheet.create({
  textHeader: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#FFFFFF"
  },
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    flexDirection: 'column',
    paddingVertical: 20,
  },
  itemContainer: {
    height: 100, 
    flexDirection:'row', 
    alignItems: 'center',
    marginVertical: 10,
    padding: 10
  },
  poster: {
    width: 100, 
    height: 100,
  },
  movieName: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#000000",
    width: "80%"
  },
  searchInput: {
    width: '90%',
    borderWidth: 2, 
    borderColor:"#3d85c6",
    borderRadius: 15,
  },
  btn: {
    backgroundColor: '#086972',
    paddingVertical: 10,
    paddingHorizontal: 20,
    margin: 10,
    borderRadius: 50,
  },
  btnText: {
    fontSize: 18,
    color: '#fff',
  },
})

export default Home;