/**
 * Tìm hiểu các core components có sẵn trong React Native
 * Component: Image
 * Biên tập: VNTALKING.COM
 */
import React, { useState } from 'react';
import { StyleSheet, View, Image , ImageBackground} from 'react-native';

const App = () => {
  const [loading, setLoading] = useState(false);

  return (
    <View style={{flex: 1}}>
      <ImageBackground source={require('./assets/images/background.jpg')}  resizeMode="cover" style={styles.imagebackground}>
        <View style={{flexDirection: 'row',justifyContent: 'center'}}>
          <View>
            <Image source={{uri: 'https://vntalking.com/wp-content/uploads/2021/05/Javascript_cover-3D-N5-300x300.png'}}  
              style={{width: 300, height: 300}} 
            />
          </View>
        </View>
        <View
          style={{
            borderBottomColor: 'black',
            borderBottomWidth: 2,
            marginTop: 5,
            marginBottom: 15
          }}
        />
        <View style={{flexDirection: 'row',justifyContent: 'center'}}>
          <Image resizeMode='cover' source={require('./assets/images/js-book-cover.png')}  
            style={{margin: 5, width: 120, height: 120}}
          />
          <Image resizeMode='contain' source={require('./assets/images/js-book-cover.png')}  
            style={{margin: 5, width: 120, height: 120}}
          />
          <Image resizeMode='stretch' source={require('./assets/images/js-book-cover.png')}  
            style={{margin: 5, width: 120, height: 120}}
          />
        </View>

      </ImageBackground>
    </View>

  )};
  const styles = StyleSheet.create({
    imagebackground: {
      flex: 1,
      justifyContent: "center"
    },
  })
export default App;

