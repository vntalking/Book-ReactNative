import React from 'react';
import { Provider} from 'react-redux';
import store from './redux/store';
import AppNavigators from './navigators/AppNavigators';
import 'react-native-gesture-handler';
// app.js
export default function App() {
  return (
    <Provider store={store}>
      <AppNavigators/>
    </Provider>
  );
}