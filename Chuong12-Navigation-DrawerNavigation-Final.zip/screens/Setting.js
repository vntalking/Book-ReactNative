/**
 * Tìm hiểu React Navigation - Tab Navigator
 * Màn hình: Setting - Thiết lập
 * Biên tập: VNTALKING.COM
*/
import React from 'react';
import { 
  StyleSheet, 
  View, 
  Text, 
  Image
} from 'react-native';

// Setting.js
const Detail = () => {
  return (
    <View style={{ flex: 1 }}>
      {/*Giao diện chính màn hình setting */}
      <View style={styles.container}>
        <Image source={ require('../assets/images/ic_setting.png')} style={styles.icon} />
        <Text style={styles.text}>Màn hình Settings</Text>
      </View>
    </View>
  )
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    justifyContent:'center',
    alignContent:'center',
    alignItems:'center'
  },
  icon: {
    width: 50,
    height: 50,
    margin: 10
  },
  text: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#000000",
  },
})

export default Detail;