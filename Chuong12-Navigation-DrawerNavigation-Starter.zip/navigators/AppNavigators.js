// navigators/AppNavigators.js
import React from 'react';
import { 
  Image
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

/**
 * Import các màn hình 
 */
import Home from '../screens/Home';
import Detail from '../screens/Detail';
import Setting from '../screens/Setting';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

const HomeStackNavigator = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Home" component={Home} options={{animationEnabled: false, header: () => null}}/>
      <Stack.Screen name="Detail" component={Detail} options={{animationEnabled: true}}/>
    </Stack.Navigator>
  );
}

const AppNavigators = () => {
  return (
    <NavigationContainer>
      <Tab.Navigator>
        <Tab.Screen name="Tab Home" component={HomeStackNavigator} options={{
          header: () => null,
          tabBarIcon: () => (
            <Image source={require('../assets/images/ic_home.png')}
              style= {{width:25, height:25}}>
            </Image>
          )
        }} />
        <Tab.Screen name="Tab Settings" component={Setting} options={{
          tabBarIcon: () => (
            <Image source={require('../assets/images/ic_setting.png')}
              style= {{width:25, height:25}}>
            </Image>
          )
        }}/>
      </Tab.Navigator>
    </NavigationContainer>
  )
}

export default AppNavigators;