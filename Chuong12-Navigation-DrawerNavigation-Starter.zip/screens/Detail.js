/**
 * Tìm hiểu React Navigation - Tab Navigator
 * Màn hình: Detail - Chi tiết
 * Biên tập: VNTALKING.COM
*/
import React from 'react';
import { 
   StyleSheet, 
   View, 
   Text, 
   Image
 } from 'react-native';

// Detail.js
const Detail = ({route}) => {
  const {params} = route;
  console.log(params)
  return (
    <View style={{ flex: 1 }}>
      {/*Giao diện chính màn hình chi tiết */}
      <View style={styles.container}>
        <Image source={{ uri: params.Poster }} style={styles.poster} />
        <View style={{ marginHorizontal: 10 }}>
            <Text style={styles.movieName}>{params.Title}</Text>
            <Text>Năm phát hành: {params.Year}</Text>
            <Text>Thể loại: {params.Type}</Text>
            <Text>Mã IMDB: {params.imdbID}</Text>
          </View>
      </View>
    </View>
  )
}

 const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  poster: {
    width: "100%", 
    height: 300,
  },
  movieName: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#000000",
    width: "80%",
  },
})

export default Detail;