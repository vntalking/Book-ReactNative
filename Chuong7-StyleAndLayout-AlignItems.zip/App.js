/**
 * Tìm hiểu về Style và Layout
 * Biên tập: VNTALKING.COM
 */
import React from 'react';
import {
  View,
  Text
} from 'react-native';

const App = () => {
  return (
    <View style={{height: 150}}>
      <Text style={{ marginBottom: 10}}>Minh họa alignItem:center</Text>
      <View style={{flexDirection: 'row', alignItems: 'center'}}>
        <View style={{ width: 50, height: 50, borderRadius: 50, backgroundColor: 'green', justifyContent:'center', alignItems: 'center'}} >
          <Text>Avatar</Text>
        </View>
        <Text>VNTALKING.COM</Text>
      </View>
    </View>
  );
};

export default App;

