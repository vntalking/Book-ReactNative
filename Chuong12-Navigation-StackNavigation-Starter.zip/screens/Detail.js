/**
 * Tìm hiểu React Navigation - Stack Navigator
 * Màn hình: Detail - Chi tiết
 * Biên tập: VNTALKING.COM
*/
import React, { useState } from 'react';
import { 
   StyleSheet, 
   View, 
   Text, 
 } from 'react-native';

 const Detail = () => {
  return (
    <View style={{ flex: 1 }}>
      <View style={{ alignItems: 'center', backgroundColor: "#cc3333" }}>
        <Text style={styles.textHeader}>Tìm hiểu Stack Navigator</Text>
        <Text style={{ color: "#FFFFFF" }}>VNTALKING.COM</Text>
      </View>
      {/*Giao diện chính màn hình chi tiết */}
      <View style={styles.container}>
        <Text style={styles.text}>
          Màn hình chi tiết
        </Text>
      </View>
    </View>
  )
}

 const styles = StyleSheet.create({
  textHeader: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#FFFFFF"
  },
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    flexDirection: 'column',
    paddingVertical: 20,
    justifyContent: 'center', 
  },
  btn: {
    backgroundColor: '#086972',
    paddingVertical: 10,
    paddingHorizontal: 20,
    margin: 10,
    borderRadius: 50,
  },
  btnText: {
    fontSize: 18,
    color: '#fff',
  },
  text: {
    fontSize: 30,
    color: "blue",
    fontWeight: 'bold'
  }
})

export default Detail;