/**
 * Tìm hiểu về Style và Layout
 * Biên tập: VNTALKING.COM
 */
import React from 'react';
import {
  View,
  Text
} from 'react-native';

const App = () => {
  return (
    <View>
      <Text style={{ padding: 10 }}>row</Text>
      <View style={{ flexDirection: 'row', width: '100%', height: 50, backgroundColor: 'whitesmoke' }}>
        <View style={{ width: 50, height: 50, backgroundColor: 'powderblue' }} />
        <View style={{ width: 50, height: 50, backgroundColor: 'skyblue' }} />
        <View style={{ width: 50, height: 50, backgroundColor: 'steelblue' }} />
      </View>
      <Text style={{ padding: 10 }}>Column</Text>
      <View style={{ flexDirection: 'column', width: '100%', height: 50, backgroundColor: 'whitesmoke' }}>
        <View style={{ width: 50, height: 50, backgroundColor: 'red' }} />
        <View style={{ width: 50, height: 50, backgroundColor: 'blue' }} />
        <View style={{ width: 50, height: 50, backgroundColor: 'orange' }} />
      </View>
    </View>

  );
};

export default App;

