/**
 * Tìm hiểu về Style và Layout
 * Biên tập: VNTALKING.COM
 */
 import React from 'react';
 import {
   View,
 } from 'react-native';
 
 const App = () => {
   return (
     <View style={{flex: 1}}>
       <View style={{flex: 1, backgroundColor: "blue"}} />
       <View style={{flex: 2, backgroundColor: "orange"}} />
       <View style={{flex: 3, backgroundColor: "red"}} />
     </View>
   );
 };
 
 export default App;
 
