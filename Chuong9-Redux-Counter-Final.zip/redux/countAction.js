// redux/countAction.js
export const increment = () => {
  return {
    type: 'INCRESE',
  };
};
 
export const decrement = () => {
  return {
    type: 'DECRESE',
  };
};