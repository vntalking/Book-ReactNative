/**
 * Tìm hiểu các core components có sẵn trong React Native
 * Component: Text
 * Biên tập: VNTALKING.COM
 */
import React from 'react';
import {
  View,
  Text
} from 'react-native';

const App = () => {
  return (
    <View style={{height: 150}}>
      <Text style={{ fontSize: 20, color: '#0321a6', fontWeight: 'bold', fontStyle: 'italic', textDecorationLine: 'underline' }}>
        Ví dụ minh họa cách sử dụng Text
      </Text>
      
      <Text style={{fontSize: 20, color: '#03a616', fontWeight: 'bold'}}
        numberOfLines={2}
        allowFontScaling={false}>
        Ví dụ minh họa cách sử dụng Text. Đây là một đoạn text vô cùng dài, 
        nó có thể tràn màn hình và sẽ bị cắt nếu diện tích màn hình không đủ.
      </Text>

      <Text style={{ fontSize: 20, color: '#a60383', fontWeight: 'bold'}}
      onPress={()=> console.log('Bạn vừa click vào text. Giờ tôi sẽ chuyển hướng tới màn hình A')}>
        Ví dụ minh họa cách sử dụng Text
      </Text>
    </View>
  );
};

export default App;

