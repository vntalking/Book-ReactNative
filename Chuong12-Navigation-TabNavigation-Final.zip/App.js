import Home from './screens/Home';
import React from 'react';
import { Provider} from 'react-redux';
import store from './redux/store';
import AppNavigators from './navigators/AppNavigators';

export default function App() {
  return (
    <Provider store={store}>
      <AppNavigators/>
    </Provider>
  );
}