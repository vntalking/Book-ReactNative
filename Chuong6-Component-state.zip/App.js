/**
 * Tìm hiểu State của Component
 * Màn hình: Home
 * Biên tập: VNTALKING.COM
 */

 import React, {useState} from 'react';
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Button
} from 'react-native';


const App = () => {

  const [count, setCount] = useState(1);
  
  return (
    <View style={{flex: 1}}>
      <View style={{ alignItems: 'center', backgroundColor: "#cc3333" }}>
        <Text style={styles.textHeader}>Tìm hiểu State của Component</Text>
        <Text style={{ color: "#FFFFFF" }}>VNTALKING.COM</Text>
      </View>
      <View style={styles.body}>
        <TouchableOpacity
            onPress={()=>setCount(count+1)}
            style={{ ...styles.btn, backgroundColor: '#3d85c6' }}>
            <Text style={styles.btnText}> Tăng lên 1 đơn vị</Text>
          </TouchableOpacity>
        <Text style={styles.text}>{count}</Text>
      </View>
    </View>

  );
};

const styles = StyleSheet.create({
  textHeader: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#FFFFFF"
  },
  body: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center', 
    paddingVertical: 20,
    borderColor: "#cc3333",
    borderWidth: 5
  },
  btn: {
    backgroundColor: '#086972',
    paddingVertical: 10,
    paddingHorizontal: 20,
    margin: 10,
    borderRadius: 10,
  },
  btnText: {
    fontSize: 18,
    color: '#fff',
  },
  text: {
    textAlign:'center', 
    fontSize: 40,
    fontWeight: "bold",
    color: "green"
  }
});

export default App;
