import Home from './screens/Home';
import React from 'react';

export default function App() {
  return <Home />;
}