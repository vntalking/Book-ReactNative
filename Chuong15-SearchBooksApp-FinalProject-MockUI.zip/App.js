/**
 * Ứng dụng tìm kiếm Ebooks
 * Biên tập: VNTALKING.COM
 */

// App.js
import React from 'react';
import AppNavigators from './src/navigators/StackNavigators';
import { NativeBaseProvider } from "native-base";

const App = () => {
  return (
    <NativeBaseProvider>
      <AppNavigators/>
    </NativeBaseProvider>
  );
};

export default App;
