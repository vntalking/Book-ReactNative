// src/navigators/StackNavigators.js
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

/**
 * Import các màn hình 
 */
import Home from '../screens/Home';
import Detail from '../screens/BookDetail';
import SearchResult from '../screens/SearchResult';
import Setting from '../screens/Setting';

const Stack = createNativeStackNavigator();

const AppStackNavigator = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={Home} options={{animationEnabled: false, header: () => null}}/>
        <Stack.Screen name="BookDetail" component={Detail} options={{title: "Thông tin sách", animationEnabled: true}}/>
        <Stack.Screen name="SearchResult" component={SearchResult} options={{title:"Kết quả tìm kiếm", animationEnabled: true}}/>
        <Stack.Screen name="Setting" component={Setting} options={{title: "Cài đặt" , animationEnabled: true}}/>
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default AppStackNavigator;