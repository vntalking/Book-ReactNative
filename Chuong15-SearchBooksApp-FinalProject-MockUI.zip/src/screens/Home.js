// src/screens/Home.js
import React from 'react';
import {
  View,
  Image,
  ImageBackground 
} from 'react-native';
import {Input, Button, Icon, Center} from 'native-base';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Card from '../components/Card';

const Home = ({ navigation }) => {

  return (
    <ImageBackground resizeMode="repeat" source={require('../assets/images/background_dot.png')} style={{width: '100%', height: '100%'}}>
      <Center flex={1} px="3">
        <Image source={require('../assets/images/logo.png')} resizeMode='center' style={{height: 150}}/>
          <Card style={{width: "100%"}}>
            <View style={{margin: 20}}>
            <Input variant="rounded" placeholder="Nhập từ khóa tìm kiếm" w="100%" />
            </View>
            <Button leftIcon={<Icon as={FontAwesome} name="search" size="sm" />} colorScheme="secondary" onPress={() => navigation.navigate("Setting")}>Tìm kiếm</Button>
          </Card>
      </Center>
    </ImageBackground>
  );
}

export default Home;