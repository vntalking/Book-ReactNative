// src/screens/SearchResult.js
import React from 'react';
import {
  Text,
  View,
  FlatList,
  StyleSheet,
  Image
} from 'react-native';
import Card from '../components/Card';
import { HStack, Button } from 'native-base';

const SearchResult = ({ navigation }) => {
  const books = [
    {
      title: "Lập trình NodeJS thật đơn giản",
      authors: [
        "VNTALKING", "Dương Anh Sơn"
      ],
      publishedDate: "01-01-2021",
      pageCount: 200,
      saleInfo: {
        country: "VN",
        listPrice: {
          amount:	89000,
          currencyCode:	"VND"
        }
      },
      imageLinks:{
        thumbnail: "https://vntalking.com/wp-content/uploads/2020/04/cover-book-nodejs-min-compressed.jpg"
      },
      buyLink: "https://vntalking.com/sach-hoc-lap-trinh-node-js-that-don-gian-html",
      description: "NodeJS là một nền tảng mở được xây dựng trên V8 JavaScript Engine- một Engine nổi tiếng của Google, được tích hợp trong Chrome. Với những ưu điểm của Node.js mà rất nhiều công ty lớn đã sử dụng nó để xây dựng ứng dụng. Chính vì điều này mà nhu cầu tuyển dụng lập trình viên biết Node.js ngày càng nhiều."
    },
    {
      title: "Lập trình ReactJS thật đơn giản",
      authors: [
        "VNTALKING", "Dương Anh Sơn"
      ],
      publishedDate: "01-01-2022",
      pageCount: 100,
      saleInfo: {
        country: "VN",
        listPrice: {
          amount:	89000,
          currencyCode:	"VND"
        }
      },
      imageLinks:{
        thumbnail: "https://vntalking.com/wp-content/uploads/2020/08/ReactJS-Cover_v3.png"
      },
      buyLink: "https://vntalking.com/tai-lieu-hoc-reactjs-tieng-viet",
      description: ""
    },
    {
      title: "Lập trình Javascript từ cơ bản tới nâng cao",
      authors: [
        "VNTALKING", "Dương Anh Sơn"
      ],
      publishedDate: "01-07-2021",
      pageCount: 100,
      saleInfo: {
        country: "VN",
        listPrice: {
          amount:	89000,
          currencyCode:	"VND"
        }
      },
      imageLinks:{
        thumbnail: "https://vntalking.com/wp-content/uploads/2021/05/Javascript_cover-3D-N5-300x300.png"
      },
      buyLink: "https://vntalking.com/tai-lieu-hoc-lap-trinh-javascript-tieng-viet",
      description: ""
    }
  ]

  const renderBookItem = (item) => {
    return (
      <Card style={{width: "95%", margin: 10}}>
        <HStack>
          <Image source={{ uri: item.imageLinks.thumbnail }} resizeMode='contain' style={styles.thumbnail} />
          <View style={{ marginHorizontal: 1, flex: 1, justifyContent:"center", alignContent:'center'}}>
            <Text style={styles.bookTitle}>{item.title}</Text>
            <Text style={styles.subText}>Ngày xuất bản: {item.publishedDate}</Text>
            <Text style={styles.subText}>Số trang: {item.pageCount}</Text>
            <Text style={styles.subText}>Giá: {item.saleInfo.listPrice.amount} {item.saleInfo.listPrice.currencyCode}</Text>
            <Button onPress={() => navigation.navigate("BookDetail", item)} size="md" style={styles.btn} variant="subtle" colorScheme="secondary">Chi tiết</Button>
          </View>
        </HStack>
      </Card>
    )
  }

  return (
    <View style={{flex: 1}}>
      <FlatList
        data={books}
        renderItem={({item}) => renderBookItem(item)}
        ListHeaderComponent={() => (!books.length ? 
          <Text>Không tìm thấy kêt quả phù hợp</Text>  
          : null)}
      />
    </View>
  );
}


const styles = StyleSheet.create({
  thumbnail: {
    width: 100, 
    height: 100,
    marginRight: 10,
  },
  bookTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#41bc66",
    width: "90%",
  },
  subText: {
    fontSize: 17,
    color: "#000000"
  },
  btn: {
    marginVertical: 10
  }
})

export default SearchResult;