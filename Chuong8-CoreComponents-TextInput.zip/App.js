/**
 * Tìm hiểu các core components có sẵn trong React Native
 * Component: TextInput
 * Biên tập: VNTALKING.COM
 */
import React from 'react';
import { View, TextInput, Text } from 'react-native';

const App = () => {
  const [number, setNumber] = React.useState(null);

  return (
    <View style={{height: 150, padding: 10}}>
      <TextInput 
      style={{
        borderWidth: 1, 
        borderColor:"#a60383",
      }}
      autoFocus={true}
      keyboardType="numeric"
      placeholder="Mời bạn nhập số gì đó nhé!"
      value={number}
      onChangeText={(num) => setNumber(num)}/>

      <Text style={{fontWeight: 'bold', color:'#0876c9'}}>Bạn vừa nhập: {number}</Text>
    </View>
  );
};

export default App;

