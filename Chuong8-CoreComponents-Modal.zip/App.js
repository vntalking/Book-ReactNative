/**
 * Tìm hiểu các core components có sẵn trong React Native
 * Component: Modal
 * Biên tập: VNTALKING.COM
 */
import React, { useState } from 'react';
import { StyleSheet, View, Button,Image, Text, Modal} from 'react-native';

const App = () => {
  const [isVisible,setVisible] = useState(false);
  const showModal = () => setVisible(true);
  return (
    <View style={{flex: 1}}>
      <View style={{alignItems: 'center', backgroundColor:"#cc3333"}}>
        <Text style={styles.textHeader}>Giới thiệu sử dụng Modal</Text>
        <Text style={{color: "#FFFFFF"}}>VNTALKING.COM</Text>
      </View>
      <View style={{flex: 1, justifyContent:'center', alignItems:'center'}}>
        <Button title='Hiển thị Modal' onPress={showModal}></Button>
      </View>
      <Modal
        animationType = {"slide"}
        transparent={true}
        visible={isVisible}>
          <View style={styles.modalContainer}>
            <View style={styles.modalBody}>
              <Image 
                source={require('./assets/images/vntalking_logo.png')}
                style = { styles.image }/>
                <Text style={styles.text }>Hướng dẫn sử dụng Modal trong React Native</Text>
                <Button title='Đóng' onPress={() => setVisible(false)}></Button>
            </View>
            
          </View>
      </Modal>
    </View>
  )};
  
  const styles = StyleSheet.create({
    textHeader: {
      fontSize: 18,
      fontWeight: "bold",
      color: "#FFFFFF"
    },
    modalContainer: {
      justifyContent:'center',
      alignItems:'center',
      flex: 1,
      backgroundColor: 'rgba(0, 0, 0, 0.4)'
    },
    modalBody: {
      backgroundColor:"#FFFFFF",
      alignItems:'center',
      paddingBottom: 10,
      borderRadius: 10,
      elevation: 20,
      borderColor: '#ccc',
      borderWidth: 1,
      borderStyle: 'solid',
    },
    image: {
      width: 80,
      height: 80,
      margin: 10,
      borderRadius: 80/2
    },
    text: {
      fontSize: 24,
      padding: 10,
      color: "#000000",
      textAlign:'center'
    }
  })
export default App;

