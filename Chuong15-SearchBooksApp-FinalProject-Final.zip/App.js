/**
 * Ứng dụng tìm kiếm Ebooks
 * Biên tập: VNTALKING.COM
 */

// App.js
import React from 'react';
import AppNavigators from './src/navigators/StackNavigators';
import { NativeBaseProvider, StatusBar} from "native-base";
import store from './src/redux/store';
import { Provider} from 'react-redux';

const App = () => {
  return (
    <Provider store={store}>
      <NativeBaseProvider >
        <StatusBar backgroundColor="white" barStyle="dark-content"/>
        <AppNavigators/>
      </NativeBaseProvider>
    </Provider>
  );
};

export default App;
