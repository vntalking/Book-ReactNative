// redux/store.js 
import { createStore, combineReducers, applyMiddleware} from 'redux';
import BookReducer from './bookReducer';

// Import thư viện Sagas
import createSagaMiddleware from 'redux-saga';
const sagaMiddleware = createSagaMiddleware();
import rootSaga from '../sagas';

const rootReducer = combineReducers({
  book: BookReducer
});

const store = createStore(rootReducer, applyMiddleware(sagaMiddleware));
// Thêm middleware Sagas vào redux
sagaMiddleware.run(rootSaga);

export default store;

