// src/screens/Home.js
import React, { useState, useEffect } from 'react';
import {
  View,
  Image,
  ImageBackground,
} from 'react-native';
import {Input, Button, Icon, Center} from 'native-base';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Card from '../components/Card';


const Home = ({ navigation }) => {

  const [keyword, setKeyword] = useState("");
  const handleChange = text => setKeyword(text);

  const search = () => {
    console.log(keyword)
    navigation.navigate("SearchResult", keyword);
  };

  return (
    <ImageBackground resizeMode="repeat" source={require('../assets/images/background_dot.png')} style={{width: '100%', height: '100%'}}>
      <Center flex={1} px="3">
        <Image source={require('../assets/images/logo.png')} resizeMode='center' style={{height: 150}}/>
          <Card style={{width: "100%"}}>
            <View style={{margin: 20}}>
            <Input variant="rounded" placeholder="Nhập từ khóa tìm kiếm" w="100%" 
              value={keyword}
              onChangeText={handleChange}/>
            </View>
            <Button onPress={search} leftIcon={<Icon as={FontAwesome} name="search" size="sm" />} colorScheme="secondary">Tìm kiếm</Button>
          </Card>
      </Center>
    </ImageBackground>
  );
}
export default Home;