// src/screens/Setting.js
import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
} from 'react-native';

import Card from '../components/Card';
import { HStack, Switch } from 'native-base';

const Setting = ({ navigation }) => {
  return (
    <Card style={{width: "95%", margin: 10}}>
      <HStack>
        <Text style={styles.label}>Dark Mode</Text>
        <Switch size="md"/>
      </HStack>
    </Card>
  );
}

const styles = StyleSheet.create({
  label: {
    fontSize: 17,
    fontWeight: "bold",
    color: "#000000",
    width: "90%",
  },
  
})

export default Setting;