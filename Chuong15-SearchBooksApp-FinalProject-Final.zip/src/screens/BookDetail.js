// src/screens/BookDetail.js
import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  Linking,
} from 'react-native';

import Card from '../components/Card';
import { HStack, Button, Divider, ScrollView} from 'native-base';

const BookDetail = ({ navigation, route }) => {
  const {params : bookInfo} = route;

  const openURLButton = async  (url) => {
    const supported = await Linking.canOpenURL(url);
    if (supported) {
      // Opening the link with some app, if the URL scheme is "http" the web link should be opened
      // by some browser in the mobile
      await Linking.openURL(url);
    }
  }

  return (
    <Card style={{width: "95%", margin: 10}}>
      <HStack>
        <Image source={{ uri: bookInfo?.volumeInfo?.imageLinks?.thumbnail }} resizeMode='contain' style={styles.thumbnail} />
        <View style={{ marginHorizontal: 1, flex: 1, justifyContent:"center", alignContent:'center'}}>
          <Text style={styles.bookTitle}>{bookInfo.volumeInfo?.title || ""}</Text>
          <Text style={styles.subText}>Ngày xuất bản: {bookInfo.volumeInfo?.publishedDate || ""}</Text>
          <Text style={styles.subText}>Số trang: {bookInfo.volumeInfo?.pageCount || 0}</Text>
          <Text style={styles.subText}>Giá: {bookInfo.saleInfo?.listPrice?.amount || 0} {bookInfo.saleInfo?.listPrice?.currencyCode || "VND"}</Text>
        </View>
      </HStack>
      <Divider style={{marginVertical: 10}}/>
      <ScrollView style={{maxHeight: 200}}>
        <Text style={styles.description}>{bookInfo?.volumeInfo?.description || "Không có miêu tả"}</Text>
      </ScrollView>
      <Button onPress={()=> openURLButton(bookInfo?.saleInfo?.buyLink || "https://vntalking.com")} size="md" style={styles.btn} >ĐỌC SÁCH</Button>
    </Card>
  );
}

const styles = StyleSheet.create({
  thumbnail: {
    width: 100, 
    height: 100,
    marginRight: 10,
  },
  bookTitle: {
    fontSize: 25,
    fontWeight: "bold",
    color: "#41bc66",
    width: "90%",
  },
  subText: {
    color: "#000000",
    fontSize: 17
  },
  description: {
    color: "#000000",
    fontSize: 17
  },
  btn: {
    marginVertical: 15
  }
})

export default BookDetail;