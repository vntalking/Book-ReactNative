/**
 * Tìm hiểu về Style và Layout
 * Biên tập: VNTALKING.COM
 */
import React from 'react';
import {
  Text,
  View,
} from 'react-native';

const App = () => {

  return (
    <View style={{flex: 1, justifyContent:'center', backgroundColor:'#002B5B', marginTop: 10}}>
      <Text style={{textAlign:'center', fontSize: 20, fontWeight: 'bold', color: '#FFFFFF'}}>Tìm hiểu Style và Layout</Text>
      <Text style={{textAlign:'center', fontSize: 14, fontStyle: 'italic', color: '#FFFFFF'}}>VNTALKING xin chào cả nhà!</Text>
    </View>
  );
};

export default App;
