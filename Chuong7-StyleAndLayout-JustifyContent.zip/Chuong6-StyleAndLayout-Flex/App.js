/**
 * Tìm hiểu về Style và Layout
 * Biên tập: VNTALKING.COM
 */
import React from 'react';
import {
  View,
  Text
} from 'react-native';

const App = () => {
  return (
    <View>
      <Text style={{ padding: 10 }}>flex-end</Text>
      <View style={{ flexDirection: 'row', justifyContent: 'flex-end', width: '100%', height: 50, backgroundColor: 'whitesmoke' }}>
        <View style={{ width: 50, height: 50, backgroundColor: 'red' }} />
        <View style={{ width: 50, height: 50, backgroundColor: 'blue' }} />
        <View style={{ width: 50, height: 50, backgroundColor: 'orange' }} />
      </View>
      <Text style={{ padding: 10 }}>space-between</Text>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', width: '100%', height: 50, backgroundColor: 'whitesmoke' }}>
        <View style={{ width: 50, height: 50, backgroundColor: 'red' }} />
        <View style={{ width: 50, height: 50, backgroundColor: 'blue' }} />
        <View style={{ width: 50, height: 50, backgroundColor: 'orange' }} />
      </View>
    </View>

  );
};

export default App;

