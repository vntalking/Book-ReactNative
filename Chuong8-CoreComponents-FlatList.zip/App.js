/**
 * Tìm hiểu các core components có sẵn trong React Native
 * Component: FlatList
 * Biên tập: VNTALKING.COM
 */
import React, { useState } from 'react';
import { StyleSheet, View, Image , FlatList, Text} from 'react-native';

const App = () => {
  const hotgirls = [
    {
      id: 1,
      thumbnail: 'https://i.pravatar.cc/150?img=28',
      name: "Thủy Phương Diễm",
      status: "Online"
    },
    {
      id: 2,
      thumbnail: 'https://i.pravatar.cc/150?img=44',
      name: "Ngô Trâm Anh",
      status: "Online"
    },
    {
      id: 4,
      thumbnail: 'https://i.pravatar.cc/150?img=1',
      name: "Triệu Thu Oanh",
      status: "Online"
    },
    {
      id: 5,
      thumbnail: 'https://i.pravatar.cc/150?img=29',
      name: "Phạm Nhã Hồng",
      status: "Offline"
    },
    {
      id: 8,
      thumbnail: 'https://i.pravatar.cc/150?img=5',
      name: "Lục Quỳnh Trâm",
      status: "Online"
    },
    {
      id: 9,
      thumbnail: 'https://i.pravatar.cc/150?img=9',
      name: "Nguyễn Kim Anh",
      status: "Online"
    },
    {
      id: 10,
      thumbnail: 'https://i.pravatar.cc/150?img=19',
      name: "Nguyễn Uyển Khanh",
      status: "Offline"
    }
  ]

  const renderHotgirlItem = (item) => {
    return (
    <View style={styles.itemContainer}>
      <Image source={{uri: item.thumbnail}} style={styles.thumbnail} />
      <View style={{marginHorizontal: 10}}>
        <Text style={styles.name}>{item.name}</Text>
        <Text>{item.status}</Text>
      </View>
    </View>
    )
  }

  return (
    <View style={{flex: 1}}>
      <View style={{alignItems: 'center', backgroundColor:"#cc3333"}}>
        <Text style={styles.textHeader}>Demo Danh sách bằng FlatList</Text>
        <Text style={{color: "#FFFFFF"}}>VNTALKING.COM</Text>
      </View>
      <FlatList
        data={hotgirls}
        renderItem={({item}) => renderHotgirlItem(item)}
      />
    </View>
  )};
  
  const styles = StyleSheet.create({
    itemContainer: {
      height: 100, 
      flexDirection:'row', 
      alignItems: 'center',
      marginVertical: 10,
      padding: 10
    },
    thumbnail: {
      width: 100, 
      height: 100,
      borderRadius: 100/ 2,
      borderColor: "#1974d2",
      borderWidth: 2
    },
    name: {
      textAlign:'center',
      fontSize: 18,
      fontWeight: "bold",
      color: "#000000"
    },
    textHeader: {
      fontSize: 18,
      fontWeight: "bold",
      color: "#FFFFFF"
    }
  })
export default App;

