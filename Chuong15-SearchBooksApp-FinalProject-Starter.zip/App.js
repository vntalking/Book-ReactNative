/**
 * Ứng dụng tìm kiếm Ebooks
 * Biên tập: VNTALKING.COM
 */

import React, {useState} from 'react';
import {
  StyleSheet,
  Text,
  View,
} from 'react-native';

// App.js
const App = () => {
  return (
    <View style={{flex: 1, justifyContent:'center', alignContent:'center', alignItems:'center'}}>
      <Text style={{ color: "#0d324d", fontSize: 30 }}>VNTALKING.COM</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  
});

export default App;
