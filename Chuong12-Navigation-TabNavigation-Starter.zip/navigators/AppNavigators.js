// navigators/AppNavigators.js
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

/**
 * Import các màn hình 
 */
import Home from '../screens/Home';
import Detail from '../screens/Detail';

const Stack = createNativeStackNavigator();

const AppNavigators = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={Home} options={{animationEnabled: false, header: () => null}}/>
        <Stack.Screen name="Detail" component={Detail} options={{animationEnabled: true}}/>
      </Stack.Navigator>
    </NavigationContainer>
  )
}

export default AppNavigators;