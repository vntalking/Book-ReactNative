/**
 * Tìm hiểu truyền dữ liệu giữa các components
 * Màn hình: Home
 * Biên tập: VNTALKING.COM
 */

import React, {useState} from 'react';
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  TextInput,
  Button
} from 'react-native';

// App.js
const ChildComponent = ({counter, parentCallback}) => {
  const [text, onChangeText] = useState("");
  const send = () => parentCallback(text);

  return (
    <View style={styles.childComponent}>
      <Text style={{color: "#000000", fontWeight:"bold", fontSize: 40,}}>Bộ đếm {counter}</Text>
      <TextInput
        value={text}
        placeholder="Gửi gì cho cha đi!"
        onChangeText={onChangeText}
        style={styles.input}
      />
      <TouchableOpacity
        onPress={send}
        style={{ ...styles.btn, backgroundColor: '#be29ec' }}>
          <Text style={styles.btnText}> Send </Text>
        </TouchableOpacity>

    </View>
  )
}

const App = () => {

  const [count, setCount] = useState(1);
  const [childrendContent, setChildrendContent] = useState(`Món quà từ con`)

  const callbackFunction = (childData) => {
    setChildrendContent(childData)
  }

  return (
    <View style={{flex: 1}}>
      <View style={{ alignItems: 'center', backgroundColor: "#0d324d" }}>
        <Text style={styles.textHeader}>Truyền dữ liệu giữa các components</Text>
        <Text style={{ color: "#FFFFFF" }}>VNTALKING.COM</Text>
      </View>
      <View style={styles.body}>
        <Text style={{textAlign:'center', fontSize: 25, color:"#000000"}}>Quà từ con:</Text>
        <Text style={{textAlign:'center', fontSize: 20, fontStyle: 'italic'}}>{childrendContent}</Text>
        <TouchableOpacity
          onPress={()=>setCount(count+1)}
          style={{ ...styles.btn, backgroundColor: '#3d85c6' }}>
            <Text style={styles.btnText}> Tăng lên 1 đơn vị</Text>
        </TouchableOpacity>
        <ChildComponent counter={count} parentCallback={callbackFunction}></ChildComponent>
        <TouchableOpacity onPress={()=> alert('Bạn đã chạm vào tôi đấy à!')}>
          <View style={styles.btn}>
            <Text style={styles.btnText}>💪 Custom Button</Text>
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  textHeader: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#FFFFFF"
  },
  body: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center', 
    paddingVertical: 20,
    borderColor: "#0d324d",
    borderWidth: 5
  },
  btn: {
    backgroundColor: '#086972',
    paddingVertical: 10,
    paddingHorizontal: 20,
    margin: 10,
    borderRadius: 10,
  },
  btnText: {
    fontSize: 18,
    color: '#fff',
  },
  text: {
    textAlign:'center', 
    fontSize: 40,
    fontWeight: "bold",
    color: "green"
  },
  childComponent: {
    borderColor: "#ffe4e1",
    borderWidth: 2,
    width: "100%",
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center', 
    backgroundColor: "#ffe4e1"
  },
  input: {
    borderWidth: 1,
    borderColor: "#be29ec",
    borderRadius: 8,
    width: "50%"
  }

});

export default App;
